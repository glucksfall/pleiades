# pleiades

<a href="https://orcid.org/0000-0003-0075-4921" target="orcid.widget" rel="noopener noreferrer" style="vertical-align:top;"><img src="https://orcid.org/sites/default/files/images/orcid_16x16.png" style="width:1em;margin-right:.5em;" alt="ORCID iD icon">orcid.org/0000-0003-0075-4921</a>

<!---[![DOI](https://zenodo.org/badge/95315412.svg)](https://zenodo.org/badge/latestdoi/95315412)--->

[![Join the chat at https://gitter.im/glucksfall/pleiades](https://badges.gitter.im/glucksfall/pleiades.svg)](https://gitter.im/glucksfall/pleiades?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
